/*
 * Course: CS1021
 * Winter 2020-2021
 * Lab 1
 * Name: Tyler Holewinski
 * Email: holewinskit@msoe.edu
 * Created: 12/1/2020
 */

package holewinskit;

import us.msoe.csse.taylor.audio.WavFile;

import java.util.Collections;
import java.util.ArrayList;
import java.util.Scanner;

import static java.lang.System.out;

/**
 * Lab 1
 * Tyler Holewinski
 * CS 1021 Q2
 *
 * This program allows the user to both reverse WAV files
 * as well as generate one-second tones of a custom frequency
 * in the WAV file format
 *
 * @author Tyler Holewinski (holewinskit@msoe.edu)
 */
public class Program {

    /**
     * Entry point for application
     *
     * @param args cli args
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        boolean done = false; // Stop the program loop

        while (!done) {
            out.println("####################");

            out.println("Commands:\n0: Quit\n1: Reverse Wav File\n" +
                    "2: Create one second of audio at a tone");
            out.println("####################");
            out.print("\n Command: ");

            String selection = in.nextLine();

            // ensure input is one character long
            if (selection.length() > 1) {
                out.println("Make sure your command selection is a single number");
                continue;
            }

            short parsedSelection;

            // ensure input is a whole number
            try {
                parsedSelection = Short.parseShort(selection);
            } catch (NumberFormatException ex) {
                out.println("Make sure your command is a whole number");
                continue;
            }

            // ensure input is bounded between 0 and 2 inclusive
            if (parsedSelection > 2 || 0 > parsedSelection) {
                out.println("Make sure your command is a listed command from the pallet");
                continue;
            }

            // handle input
            switch (parsedSelection) {
                case 0:
                    done = true;
                    break;
                case 1:

                    out.print("\n\n* Reverse Audio Mode *\nCurrent Folder: " + System.getProperty("user.dir") + "\nTarget File (full path, less the extension): ");
                    String targetFile = in.nextLine() + ".wav";

                    out.print("\nDestination File (less the extension): ");
                    String destFile = in.nextLine() + ".wav";

                    generateReversedAudioWAVFile(targetFile, destFile);
                    break;
                case 2:
                    out.print("\n\n* Tone Mode *\nCurrent Folder: " +
                            System.getProperty("user.dir") + "\nFrequency (Hz): ");
                    int inFreq = Integer.parseInt(in.nextLine());
                    out.print("\nSave file to (less filename): ");
                    String savePath = in.nextLine();

                    generateTone(inFreq, savePath + ".wav");
            }
        }
    }

    /**
     * Reverse the audio of an existing wav file, and save it to a new wav file
     * @param currentFile the path of the existing wav file to target
     * @param destFile the path of the new file to save to reversed file to
     */
    // Must catch super class "Exception" since class WavFile does not denote a specifically thrown exception
    @SuppressWarnings("checkstyle:IllegalCatch")
    static void generateReversedAudioWAVFile(String currentFile, String destFile) {
        out.print("Processing...");

        try {
            WavFile readWav = new WavFile(currentFile);
            WavFile writeWav = new WavFile(destFile,
                    readWav.getNumChannels(),
                    readWav.getNumFrames(),
                    readWav.getValidBits(),
                    readWav.getSampleRate());

            ArrayList<Double> samples = readWav.getSamples();
            Collections.reverse(samples);

            writeWav.setSamples(samples);
            writeWav.close();
            readWav.close();

            out.println("\nDone");
        } catch (Exception ex) {
            out.println("\n*** ERROR ***\n" +
                    "File could not be found.\n" +
                    "Are you including 'resources' to specify the resource folder?");
        }
    }

    /**
     * Generate a one second tone and save it to a WAV file
     * @param frequency the frequency, in Hz, of the tone
     * @param savePath the filepath to save the .wav file to. (.wav must be included)
     */
    static void generateTone(double frequency, String savePath) {
        out.println("Processing...");
        final short channels = 1;
        final short numFrames = 8000;
        final short bits = 8;
        final short sampleRate = 8000;

        WavFile writeWav = new WavFile(savePath, channels, numFrames, bits, sampleRate);
        ArrayList<Double> samples = new ArrayList<>();

        for (short i = 0; i < sampleRate; i++) {
            double n = Math.sin(Math.PI * 2 * i);
            samples.add(Math.sin(Math.PI * 2 * i * (frequency / sampleRate)));
        }

        writeWav.setSamples(samples);
        writeWav.close();

        out.println("\nDone");
    }
}
